--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE vinovault;
--
-- Name: vinovault; Type: DATABASE; Schema: -; Owner: vvadmin
--

CREATE DATABASE vinovault WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE vinovault OWNER TO vvadmin;

\connect vinovault

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: enforce_rating_constraints(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.enforce_rating_constraints() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.Rating < 1 OR NEW.Rating > 5 THEN
        RAISE EXCEPTION 'Rating must be between 1 and 5';
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.enforce_rating_constraints() OWNER TO postgres;

--
-- Name: last_updated(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.last_updated() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.last_updated = now();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.last_updated() OWNER TO postgres;

--
-- Name: update_date_reviewed(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_date_reviewed() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.DateReviewed = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_date_reviewed() OWNER TO postgres;

--
-- Name: update_search_vector(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_search_vector() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.search_vector := to_tsvector('english', 
        coalesce(NEW.Name, '') || ' ' || 
        coalesce(NEW.Winery, '') || ' ' || 
        coalesce(NEW.Region, '') || ' ' || 
        coalesce(NEW.Country, '') || ' ' || 
        coalesce(NEW.Type, '') || ' ' || 
        coalesce(NEW.Color, '') || ' ' || 
        coalesce(NEW.Description, '')
    );
    RETURN NEW;
END
$$;


ALTER FUNCTION public.update_search_vector() OWNER TO postgres;

--
-- Name: update_winery_logo(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_winery_logo() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.WineryLogo := (SELECT logo FROM Winery WHERE WineryID = NEW.WineryID);
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_winery_logo() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: reviews; Type: TABLE; Schema: public; Owner: vvadmin
--

CREATE TABLE public.reviews (
    reviewid integer NOT NULL,
    tastingnotes text,
    reviewtext text,
    rating integer,
    datereviewed timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    wineid integer,
    CONSTRAINT reviews_rating_check CHECK (((rating >= 1) AND (rating <= 5)))
);


ALTER TABLE public.reviews OWNER TO vvadmin;

--
-- Name: wine; Type: TABLE; Schema: public; Owner: vvadmin
--

CREATE TABLE public.wine (
    wineid integer NOT NULL,
    name character varying(100) NOT NULL,
    winery character varying(100),
    region character varying(100),
    country character varying(100),
    type character varying(50) NOT NULL,
    color character varying(50) NOT NULL,
    price numeric(10,2) NOT NULL,
    rating integer,
    description text,
    logo character varying(255),
    search_vector tsvector,
    CONSTRAINT wine_rating_check CHECK (((rating >= 1) AND (rating <= 5)))
);


ALTER TABLE public.wine OWNER TO vvadmin;

--
-- Name: View_ReviewsByName; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public."View_ReviewsByName" AS
 SELECT reviews.reviewid,
    reviews.tastingnotes,
    reviews.reviewtext,
    reviews.rating AS reviewrating,
    reviews.datereviewed,
    wine.name AS winename,
    wine.winery,
    wine.region,
    wine.country,
    wine.type,
    wine.color,
    wine.price,
    wine.rating AS winerating,
    wine.description,
    wine.logo
   FROM (public.reviews
     JOIN public.wine ON ((reviews.wineid = wine.wineid)))
  WHERE ((wine.name)::text = 'Penfolds Bin 389'::text);


ALTER VIEW public."View_ReviewsByName" OWNER TO postgres;

--
-- Name: View_WineByName; Type: VIEW; Schema: public; Owner: vvadmin
--

CREATE VIEW public."View_WineByName" AS
 SELECT wine.wineid,
    wine.name,
    wine.winery,
    wine.region,
    wine.country,
    wine.type,
    wine.color,
    wine.price,
    wine.rating,
    wine.description,
    wine.logo,
    wine.search_vector
   FROM public.wine
  WHERE ((wine.name)::text = 'Penfolds Grange 2016'::text);


ALTER VIEW public."View_WineByName" OWNER TO vvadmin;

--
-- Name: View_WineByWinery; Type: VIEW; Schema: public; Owner: vvadmin
--

CREATE VIEW public."View_WineByWinery" AS
 SELECT wine.wineid,
    wine.name,
    wine.winery,
    wine.region,
    wine.country,
    wine.type,
    wine.color,
    wine.price,
    wine.rating,
    wine.description,
    wine.logo,
    wine.search_vector
   FROM public.wine
  WHERE ((wine.winery)::text = 'Penfolds'::text);


ALTER VIEW public."View_WineByWinery" OWNER TO vvadmin;

--
-- Name: Views_WineByType; Type: VIEW; Schema: public; Owner: vvadmin
--

CREATE VIEW public."Views_WineByType" AS
 SELECT wine.wineid,
    wine.name,
    wine.winery,
    wine.region,
    wine.country,
    wine.type,
    wine.color,
    wine.price,
    wine.rating,
    wine.description,
    wine.logo,
    wine.search_vector
   FROM public.wine
  WHERE ((wine.type)::text = 'Chardonnay'::text);


ALTER VIEW public."Views_WineByType" OWNER TO vvadmin;

--
-- Name: allreviews; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.allreviews AS
 SELECT reviews.reviewid,
    reviews.tastingnotes,
    reviews.reviewtext,
    reviews.rating AS reviewrating,
    reviews.datereviewed,
    wine.name AS winename,
    wine.winery,
    wine.region,
    wine.country,
    wine.type,
    wine.color,
    wine.price,
    wine.rating AS winerating,
    wine.description,
    wine.logo
   FROM (public.reviews
     JOIN public.wine ON ((reviews.wineid = wine.wineid)));


ALTER VIEW public.allreviews OWNER TO postgres;

--
-- Name: allwines; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.allwines AS
 SELECT wine.wineid,
    wine.name,
    wine.winery,
    wine.region,
    wine.country,
    wine.type,
    wine.color,
    wine.price,
    wine.rating,
    wine.description,
    wine.logo,
    wine.search_vector
   FROM public.wine;


ALTER VIEW public.allwines OWNER TO postgres;

--
-- Name: inventory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory (
    inventoryid integer NOT NULL,
    retailerid integer NOT NULL,
    wineid integer NOT NULL,
    stock integer NOT NULL,
    price numeric(10,2) NOT NULL,
    createdat timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updatedat timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.inventory OWNER TO postgres;

--
-- Name: inventory_inventoryid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inventory_inventoryid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inventory_inventoryid_seq OWNER TO postgres;

--
-- Name: inventory_inventoryid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inventory_inventoryid_seq OWNED BY public.inventory.inventoryid;


--
-- Name: retailers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.retailers (
    retailerid integer NOT NULL,
    name character varying(100) NOT NULL,
    location character varying(100) NOT NULL,
    createdat timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updatedat timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.retailers OWNER TO postgres;

--
-- Name: retailers_retailerid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.retailers_retailerid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.retailers_retailerid_seq OWNER TO postgres;

--
-- Name: retailers_retailerid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.retailers_retailerid_seq OWNED BY public.retailers.retailerid;


--
-- Name: reviews_reviewid_seq; Type: SEQUENCE; Schema: public; Owner: vvadmin
--

CREATE SEQUENCE public.reviews_reviewid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reviews_reviewid_seq OWNER TO vvadmin;

--
-- Name: reviews_reviewid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vvadmin
--

ALTER SEQUENCE public.reviews_reviewid_seq OWNED BY public.reviews.reviewid;


--
-- Name: wine_wineid_seq; Type: SEQUENCE; Schema: public; Owner: vvadmin
--

CREATE SEQUENCE public.wine_wineid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wine_wineid_seq OWNER TO vvadmin;

--
-- Name: wine_wineid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vvadmin
--

ALTER SEQUENCE public.wine_wineid_seq OWNED BY public.wine.wineid;


--
-- Name: inventory inventoryid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory ALTER COLUMN inventoryid SET DEFAULT nextval('public.inventory_inventoryid_seq'::regclass);


--
-- Name: retailers retailerid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.retailers ALTER COLUMN retailerid SET DEFAULT nextval('public.retailers_retailerid_seq'::regclass);


--
-- Name: reviews reviewid; Type: DEFAULT; Schema: public; Owner: vvadmin
--

ALTER TABLE ONLY public.reviews ALTER COLUMN reviewid SET DEFAULT nextval('public.reviews_reviewid_seq'::regclass);


--
-- Name: wine wineid; Type: DEFAULT; Schema: public; Owner: vvadmin
--

ALTER TABLE ONLY public.wine ALTER COLUMN wineid SET DEFAULT nextval('public.wine_wineid_seq'::regclass);


--
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory (inventoryid, retailerid, wineid, stock, price, createdat, updatedat) FROM stdin;
\.
COPY public.inventory (inventoryid, retailerid, wineid, stock, price, createdat, updatedat) FROM '$$PATH$$/3665.dat';

--
-- Data for Name: retailers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.retailers (retailerid, name, location, createdat, updatedat) FROM stdin;
\.
COPY public.retailers (retailerid, name, location, createdat, updatedat) FROM '$$PATH$$/3663.dat';

--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: vvadmin
--

COPY public.reviews (reviewid, tastingnotes, reviewtext, rating, datereviewed, wineid) FROM stdin;
\.
COPY public.reviews (reviewid, tastingnotes, reviewtext, rating, datereviewed, wineid) FROM '$$PATH$$/3661.dat';

--
-- Data for Name: wine; Type: TABLE DATA; Schema: public; Owner: vvadmin
--

COPY public.wine (wineid, name, winery, region, country, type, color, price, rating, description, logo, search_vector) FROM stdin;
\.
COPY public.wine (wineid, name, winery, region, country, type, color, price, rating, description, logo, search_vector) FROM '$$PATH$$/3659.dat';

--
-- Name: inventory_inventoryid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventory_inventoryid_seq', 1, false);


--
-- Name: retailers_retailerid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.retailers_retailerid_seq', 1, false);


--
-- Name: reviews_reviewid_seq; Type: SEQUENCE SET; Schema: public; Owner: vvadmin
--

SELECT pg_catalog.setval('public.reviews_reviewid_seq', 818, true);


--
-- Name: wine_wineid_seq; Type: SEQUENCE SET; Schema: public; Owner: vvadmin
--

SELECT pg_catalog.setval('public.wine_wineid_seq', 435, true);


--
-- Name: inventory inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_pkey PRIMARY KEY (inventoryid);


--
-- Name: retailers retailers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.retailers
    ADD CONSTRAINT retailers_pkey PRIMARY KEY (retailerid);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: vvadmin
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (reviewid);


--
-- Name: wine wine_pkey; Type: CONSTRAINT; Schema: public; Owner: vvadmin
--

ALTER TABLE ONLY public.wine
    ADD CONSTRAINT wine_pkey PRIMARY KEY (wineid);


--
-- Name: wine_search_idx; Type: INDEX; Schema: public; Owner: vvadmin
--

CREATE INDEX wine_search_idx ON public.wine USING gin (search_vector);


--
-- Name: reviews enforce_rating_constraints_trigger; Type: TRIGGER; Schema: public; Owner: vvadmin
--

CREATE TRIGGER enforce_rating_constraints_trigger BEFORE INSERT OR UPDATE ON public.reviews FOR EACH ROW EXECUTE FUNCTION public.enforce_rating_constraints();


--
-- Name: wine tsvectorupdate; Type: TRIGGER; Schema: public; Owner: vvadmin
--

CREATE TRIGGER tsvectorupdate BEFORE INSERT OR UPDATE ON public.wine FOR EACH ROW EXECUTE FUNCTION public.update_search_vector();


--
-- Name: reviews update_date_reviewed_trigger; Type: TRIGGER; Schema: public; Owner: vvadmin
--

CREATE TRIGGER update_date_reviewed_trigger BEFORE UPDATE ON public.reviews FOR EACH ROW EXECUTE FUNCTION public.update_date_reviewed();


--
-- Name: inventory fk_retailer; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT fk_retailer FOREIGN KEY (retailerid) REFERENCES public.retailers(retailerid) ON DELETE CASCADE;


--
-- Name: inventory fk_wine; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT fk_wine FOREIGN KEY (wineid) REFERENCES public.wine(wineid) ON DELETE CASCADE;


--
-- Name: reviews fk_wine; Type: FK CONSTRAINT; Schema: public; Owner: vvadmin
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT fk_wine FOREIGN KEY (wineid) REFERENCES public.wine(wineid) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

